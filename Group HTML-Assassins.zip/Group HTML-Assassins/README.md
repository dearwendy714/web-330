# HTML-Assassins
JavaScript Design Patterns
4 Contributors
Kurt Leadley - Bellevue University
Karie Funk - Bellevue University
Wendy Portillo - Bellevue University
Keith Kozma - Bellevue University
Team project for Web-330
