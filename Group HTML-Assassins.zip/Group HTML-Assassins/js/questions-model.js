    // JSON object to hold all our questions and answers - kl
    // add some questions here
    var questions = {
        "one": {
            "question": "What does js stand for?",
            "answerOne":"jQuery Script",
            "answerTwo":"Java Serialized",
            "answerThree":"JSONScript",
            "answerFour":"JavaScript",
            "correctAnswer":"answerFour",
            "userAnswer" : "",
            "display" : true
        },
        "two": {
            "question":"How do you print a message to the console?",
            "answerOne":"Logger.log();",
            "answerTwo":"console.log();",
            "answerThree":"console.log[];",
            "answerFour":"Console.log();",
            "correctAnswer":"answerTwo",
            "userAnswer" : "",
            "display" : false 
        },
        "three": {
            "question":"How do you push a value to an array?",
            "answerOne":"array.push(value);",
            "answerTwo":"push[array,value];",
            "answerThree":"array_push(array,value);",
            "answerFour":"array.push[value];",
            "correctAnswer":"answerOne",
            "userAnswer" : "",
            "display" : false 
        },
        "four": {
            "question":"How do you print a message to the console?",
            "answerOne":"Logger.log()",
            "answerTwo":"console.log()",
            "answerThree":"console.log[]",
            "answerFour":"Console.log()",
            "correctAnswer":"answerTwo", 
            "userAnswer" : "",
            "display" : false 
        },
        "five": {
            "question":"How do you print a message to the console?",
            "answerOne":"Logger.log()",
            "answerTwo":"console.log()",
            "answerThree":"console.log[]",
            "answerFour":"Console.log()",
            "correctAnswer":"answerTwo",
            "userAnswer" : "",
            "display" : false 
        },
        "six": {
            "question":"How do you push a value to an array?",
            "answerOne":"array.push(value);",
            "answerTwo":"push[array,value];",
            "answerThree":"array_push(array,value);",
            "answerFour":"array.push[value];",
            "correctAnswer":"answerOne",
            "userAnswer" : "",
            "display" : false 
        },
        "seven": {
            "question":"How do you print a message to the console?",
            "answerOne":"Logger.log()",
            "answerTwo":"console.log()",
            "answerThree":"console.log[]",
            "answerFour":"Console.log()",
            "correctAnswer":"answerTwo",
            "userAnswer" : "",
            "display" : false 
        },
        "eight": {
            "question": "What does js stand for?",
            "answerOne":"jQuery Script",
            "answerTwo":"Java Serialized",
            "answerThree":"JSONScript",
            "answerFour":"JavaScript",
            "correctAnswer":"answerFour",
            "userAnswer" : "",
            "display" : false 
        },
        "nine": {
            "question":"How do you print a message to the console?",
            "answerOne":"Logger.log()",
            "answerTwo":"console.log()",
            "answerThree":"console.log[]",
            "answerFour":"Console.log()",
            "correctAnswer":"answerTwo",
            "userAnswer" : "",
            "display" : false 
        },
        "ten": {
            "question":"How do you print a message to the console?",
            "answerOne":"Logger.log()",
            "answerTwo":"console.log()",
            "answerThree":"console.log[]",
            "answerFour":"Console.log()",
            "correctAnswer":"answerTwo",
            "userAnswer" : "",
            "display" : false 
        }
    }